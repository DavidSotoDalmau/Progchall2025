export class InventoryUI {
  constructor(scene, gameState){ this.scene=scene; this.gameState=gameState; }
  render(){ /* draw inventory slots */ }
  add(item){ /* animate add */ }
}

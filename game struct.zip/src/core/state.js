import { GameState } from "./GameState.js";
export const gameState = new GameState();
